"""Document business logic."""

