"""Vector store integrations."""
