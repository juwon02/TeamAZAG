"""Core application configuration."""
